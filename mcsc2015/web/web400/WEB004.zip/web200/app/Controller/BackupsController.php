<?php 

/**
* 
*/
class BackupsController extends AppController
{
	function beforeFilter()
	{
		$this->Auth->allow('index');
	}
	public  function index()
	{
	  

	}

	
}
 ?>