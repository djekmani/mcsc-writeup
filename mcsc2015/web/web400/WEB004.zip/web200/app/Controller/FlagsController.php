<?php 
/*

*/
class FlagsController extends AppController
{

	public function index()
	{

	}

	public function getFlag()
	{
		if($this->Auth->user('is_admin'))
		{
			debug($this->Flag->findById(1));
			die();
		}
	}
	
}

?>
