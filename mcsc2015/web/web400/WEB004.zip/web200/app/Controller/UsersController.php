<?php 
/*

*/
class UsersController extends AppController
{

		public function testing()
		{
			debug($this->User->find('all' , array('fields' => array('id' , 'username' , 'is_admin'))));
			die();

		}
		private function users()
		{
			return $this->User->find('all');
		}
		public function index()
		{

		}

		public function profile($id)
		{
			if($id != null && $this->User->exists($id) && $this->Auth->user('id') == $id)
			{
				$user = $this->User->findById($id);
				$this->set(compact('user'));
			}
			else
			{
				$this->redirect(array('action' => 'error'));
			}
		}

		public function add($id=null)
		{	
			if($id == null)
			{

				if($this->Auth->user('is_admin'))
				{
					if(!empty($this->request->data))
					{
						$data = $this->data;
						$data['User']['password'] = $this->Auth->password($data['User']['password']);
						if($this->User->save($data))
						{
							$this->redirect(array('action' => 'profile', $id));
						}
					}
				}
				else
				{
					$this->redirect(array('action' => 'error'));
				}
			}
	
			else
			{
				if($this->User->exists($id) && $id == $this->Auth->user('id'))
				{
					if(!empty($this->request->data))
						{
							if(isset($this->request->data['User']['is_admin']) || isset($this->request->data['User']['username']))
							{
								$this->redirect(array('action' => 'error'));
							}
							$data = $this->data;
							$data['User']['password'] = $this->Auth->password($data['User']['password']);
							if($this->User->save($data))
							{
								$this->redirect(array('action' => 'profile' , $id));
							}
							else
							{
								$this->redirect(array('action' => 'error'));
							}
						}
					$this->User->id = $id;
					$this->data = $this->User->read();
				}
				else
				{
					$this->redirect(array('action' => 'error'));
				}
			}

		}

		public function delete($id)
		{
			if($id != null)
			{
				$this->User->delete($id);
				$this->redirect(array('action' => 'index'));
			}
		}


		public function login()
		{
			$this->layout = false;
			if ($this->request->is('post'))
			{
				if (!empty($this->request->data['User']['username']) && !empty($this->request->data['User']['password']) )
				{

					if($this->Auth->login())
					{						
						$this->redirect(array('action' => 'profile' , $this->Auth->user('id')));
					}
					else
					{
						$this->Session->setFlash('Login et password incorrect', 'error');

					}	
				}
				else
				{
					$this->Session->setFlash('Vous devez remplir les champs pour se connecter', 'error');

				}
			}
		}

		public function logout()
		{
			$this->Auth->logout();
			$this->redirect(array('action' => 'login'));

		}

		public function error()
		{
			$this->layout = false;

		}
}

?>