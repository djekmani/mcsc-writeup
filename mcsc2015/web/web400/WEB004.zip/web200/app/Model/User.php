<?php 

/**
* 
*/
class User extends AppModel
{
	
	public function beforeSave($options = array())
	{
		if(!AuthComponent::user('is_admin'))
		{
			if($this->data['User']['id'] == AuthComponent::user('id') || $this->data['User']['id'] == 10)
			{
				return true;
			}
			else return false;
		}
		return true;
	}	

}
 ?>